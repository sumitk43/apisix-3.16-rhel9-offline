# APISIX and OpenResty Prerequisites and Module Scope

Management overview and acquisition checklist for APISIX 3.18.0 with OpenResty 1.31.1.1 on RHEL 9 x86_64. We will obtain public upstream archives, adapt and apply 38 runtime patches manually, then compile and validate the gateway. The companion manual runbook explains every patch command and its purpose.

## 1 Outcome and current evidence

The manual shell patch commands were validated on 12 October 2026. All 38 patches passed forward-only, zero-fuzz application and a second replay on fresh sources. The resulting 2,994 source files matched the earlier verified source tree byte for byte. The earlier Docker rehearsal compiled OpenResty and passed ten HTTP gateway requests, an unmatched-route 404 and a check for new runtime errors. The work RHEL9 build and the newly documented manual compilation procedure still require execution there.

The goal is a reproducible internal patching page with source links, command rationale, patch order, versions and test evidence. This is a custom compatibility port; the route test does not establish functional coverage of every TLS, stream, Wasm, HTTP3 or privileged-agent feature.

## 2 What is being patched

| Runtime component | Version | Patch count | Integration purpose |
| --- | --- | --- | --- |
| Nginx inside OpenResty | 1.31.1 | 18 | HTTP/stream hooks, TLS decisions, metrics, filtering and multi-upstream integration. |
| Lua core wrappers | 0.1.34rc3 | 6 | Lua APIs corresponding to native balancer, SSL and shared-dictionary hooks. |
| HTTP Lua module | 0.10.31rc5 | 8 | Native HTTP Lua lifecycle, keepalive, TLS, headers and dictionaries. |
| Stream Lua module | 0.0.19rc4 | 6 | Native stream Lua TLS, dictionaries and xRPC integration. |
| APISIX Lua application | 3.18.0 | 0 separate runtime patches | Installed with dependencies and configured to use the patched OpenResty runtime. |

The total is one multi-upstream patch plus 37 patches supplied with apisix-nginx-module 1.19.10. Ten patch files need adaptation or consolidation for the new sources; the remaining 28 can be applied unchanged. APISIX HTTP, stream and meta C modules are compiled as addons. Their role is to implement the APIs referenced by the patches; we do not edit their addon source in this procedure.

## 3 Business capability mapping

| Capability | Modules affected | Why the gateway needs the hooks |
| --- | --- | --- |
| Upstream reuse and protocols | Multi-upstream, HTTP Lua balancer, Dubbo and xRPC | Provide connection reuse and protocol-specific integration used by gateway features. |
| TLS control | Nginx upstream, Lua SSL wrappers and HTTP/stream cosockets | Let APISIX supply certificates, control verification and manage TLS sessions. |
| Request and response control | Nginx core/proxy/gzip/mirror/trailers and HTTP Lua filters | Apply route or request decisions through native runtime hooks. |
| State and worker integration | Lua core, HTTP Lua, stream Lua and meta Lua | Keep shared dictionaries and initialization handlers consistent across integrations. |
| Diagnostics and identity | Stream proxy metrics, real IP, original destination and log reopen hooks | Expose connection reasons and address/log metadata for runtime integrations. |

## 4 Public downloads and component usage

Open each URL in a browser and save the exact filename shown. Transfer archives to /tmp/apisix_build_dryrun/downloads/. GitHub may suggest a short filename such as 1.19.10.tar.gz; rename it to the filename below. These are public inputs. No earlier custom patch seed, prepared patch archive, Python patch generator or shell wrapper is required for the manual patch steps.

**openresty-1.31.1.1.tar.gz**

https://openresty.org/download/openresty-1.31.1.1.tar.gz

Contains all four runtime components being patched, plus LuaJIT and the bundled OpenResty modules.

**apisix-3.18.0.tar.gz**

https://github.com/apache/apisix/archive/refs/tags/3.18.0.tar.gz

Gateway application, CLI, plugins, Makefile and dependency rockspec. Installed after runtime compilation.

**openssl-3.4.1.tar.gz**

https://github.com/openssl/openssl/releases/download/openssl-3.4.1/openssl-3.4.1.tar.gz

Private TLS library matching the successful rehearsal. System OpenSSL 3.5 remains installed separately.

**luarocks-3.11.1.tar.gz**

https://luarocks.org/releases/luarocks-3.11.1.tar.gz

Lua package manager for dependency inventory and optional dependency rebuilding.

**lua-resty-limit-traffic-1.2.0.tar.gz**

https://github.com/api7/lua-resty-limit-traffic/archive/refs/tags/v1.2.0.tar.gz

Lua rate/concurrency helpers installed into site/lualib; no source patch in this procedure.

**lua-resty-events-0.2.0.tar.gz**

https://github.com/Kong/lua-resty-events/archive/refs/tags/0.2.0.tar.gz

Events C addon and Lua wrappers, including compat/init.lua; compiled and installed without source edits.

**ngx_multi_upstream_module-1.3.4.tar.gz**

https://github.com/api7/ngx_multi_upstream_module/archive/refs/tags/1.3.4.tar.gz

Public Nginx 1.29.2 patch and addon sources. Its patch is adapted first for Nginx 1.31.1.

**mod_dubbo-1.0.2.tar.gz**

https://github.com/api7/mod_dubbo/archive/refs/tags/1.0.2.tar.gz

Dubbo protocol addon; compiled without source edits.

**apisix-nginx-module-1.19.10.tar.gz**

https://github.com/api7/apisix-nginx-module/archive/refs/tags/1.19.10.tar.gz

Public 37-patch input set under patch/1.29.2.4; HTTP, stream and meta addons; resty.apisix Lua wrappers.

**wasm-nginx-module-0.7.0.tar.gz**

https://github.com/api7/wasm-nginx-module/archive/refs/tags/0.7.0.tar.gz

Wasm addon compiled with staged Wasmtime headers/library; no source patch here.

**lua-var-nginx-module-v0.5.3.tar.gz**

https://github.com/api7/lua-var-nginx-module/archive/refs/tags/v0.5.3.tar.gz

Native variable-access addon; compiled without source edits.

**ngx_http_ffi_client-v0.1.3.tar.gz**

https://github.com/api7/ngx_http_ffi_client/archive/refs/tags/v0.1.3.tar.gz

HTTP FFI addon with vendored llhttp parser; requires the patched HTTP Lua API header path.

**wasmtime-v0.38.1-x86_64-linux-c-api.tar.xz**

https://github.com/bytecodealliance/wasmtime/releases/download/v0.38.1/wasmtime-v0.38.1-x86_64-linux-c-api.tar.xz

Published prebuilt Wasmtime C API. We reuse it rather than compiling Rust/Cargo sources.

## 5 Bundled modules and acquisition boundaries

Nginx 1.31.1, lua-resty-core 0.1.34rc3, ngx_lua 0.10.31rc5, ngx_stream_lua 0.0.19rc4 and LuaJIT are already inside the OpenResty archive. Do not download independent newer copies to substitute for these directories. Their exact versions and API pairs are part of the patch baseline.

The existing offline APISIX installation path reuses apisix-lua-dependencies.tar.gz and openresty-site-lualib.tar.gz from the successful rehearsal. These archives contain assembled dependencies and Lua wrappers; they are not the custom patch seed. Their exact archives are local outputs even though their constituent packages are public. Transfer both and their original trusted SHA256SUMS for the offline path. Preserve apisix-luarocks-installed.tsv and build-environment.txt to assess native EL9 library compatibility.

If dependencies are rebuilt instead, the runbook includes the connected LuaRocks command using standard Lua with LuaJIT-targeted headers. That command downloads dependencies and may invoke source tools. It must run only where such downloads are permitted. A fully browser-only source-rock mirror for all 79 resolved packages is not supplied here; do not run the network dependency command in the restricted work environment.

## 6 Build prerequisites from approved RHEL repositories

Create the logs directory before running this command. Use approved RHEL repositories or an internally prepared matching RPM set. Repository names and availability depend on the work host subscription or mirror. Do not add Rocky Linux repositories to RHEL. Some development packages may require the approved builder repository.

```bash
mkdir -p /tmp/apisix_build_dryrun/{downloads,work,repo,logs,transfer}
cd /tmp/apisix_build_dryrun
set -o pipefail
yum repolist
yum install -y \
  gcc gcc-c++ make patch perl perl-IPC-Cmd \
  autoconf automake libtool cmake ninja-build pkgconf-pkg-config \
  ca-certificates tar gzip bzip2 xz unzip \
  findutils diffutils which gawk coreutils \
  zlib-devel pcre-devel pcre2-devel openssl-devel \
  libxml2-devel libxslt-devel libyaml-devel libffi-devel \
  openldap-devel readline-devel ncurses-devel \
  2>&1 | tee logs/prerequisites-install.log
perl -MIPC::Cmd -e 'print "IPC::Cmd OK\n"'
rpm -q zlib-devel pcre-devel pcre2-devel openssl-devel
ls -l /usr/include/pcre.h /usr/include/zlib.h
```

| Package group | Usage |
| --- | --- |
| gcc gcc-c++ make | Compile OpenResty, addons, OpenSSL and native Lua bindings. |
| patch diffutils gawk coreutils | Apply changes, produce source diffs, inspect or repair exact source context, compute checksums and run timeout-limited tests. |
| perl perl-IPC-Cmd | Configure OpenSSL and run its tests. |
| cmake ninja-build autoconf automake libtool pkgconf | Build-system and header/library discovery tools, including native dependency builds. |
| tar gzip bzip2 xz unzip findutils | Extract public archives, locate files and inspect generated patches. |
| zlib-devel pcre-devel | Use EL9 compression and PCRE8 regex/JIT libraries instead of rebuilding them. |
| pcre2-devel openssl-devel | General development prerequisites retained from the rehearsal; this runtime explicitly selects PCRE8 and private OpenSSL headers. |
| XML XSLT YAML FFI LDAP and terminal development RPMs | Headers/link libraries needed by selected native Lua dependencies and source builds. |

## 7 Optional acquisition tools kept separate

Git, curl and wget are acquisition tools on the connected personal machine. They are not required to patch or build from transferred archives. The manual local HTTP test uses Bash sockets and OpenResty itself, so it does not require curl. Existing curl-minimal can fetch HTTPS archives; requesting full curl unnecessarily caused the earlier package conflict.

```bash
# Optional on the connected personal machine only.
yum install -y git wget
git --version
curl --version
```

The shell patch commands do not use Python. Standard Lua is needed only for the optional connected dependency rebuild; install it from that builder host approved package repository. Wasmtime does not require Rust in this workflow.

## 8 Input integrity and compatibility checks

```bash
65b78baadd3f0984055de89bf13f4a1932e5bfe9c31932037a134ea2b1a0ce42  openresty-1.31.1.1.tar.gz
bc0dad68782972aa28c7da36b7b84ed2667ce293eb6a23837e821866e14bc221  apisix-nginx-module-1.19.10.tar.gz
d68b22ea0cb523bffa2990ed6656827a0a74c6b223235d5c19e8df87deae9833  ngx_multi_upstream_module-1.3.4.tar.gz
```

These SHA256 values are the three tested public input archives. Verify from downloads/ before extraction. Preserve trusted checksums for the other downloads on the connected acquisition machine. Do not treat a newly calculated checksum of an unverified destination file as proof of provenance. A mismatch requires investigation rather than disabling the check.

Target architecture is x86_64 and target OS family is EL9. The prebuilt Wasmtime library and every native Lua .so must resolve with ldd on the work host. The work host system OpenSSL may be 3.5; the documented runtime build still uses private 3.4.1. Using system 3.5 instead is a separate unvalidated variant that requires different include/library paths and tests.

## 9 Complete patch inventory

Numbers below are the execution order in the manual runbook. Public means an unchanged upstream patch. Adapt means source-context porting or consolidation before applying a locally generated diff. The full command rationale is in the companion document.

| Step | Patch file | Method | Capability |
| --- | --- | --- | --- |
| 01 | nginx-1.31.1.patch | Adapt | Multi-upstream state |
| 02 | nginx-client_max_body_size.patch | Public | Request body limit |
| 03 | nginx-connection-original-dst.patch | Public | Original destination variable |
| 04 | nginx-enable_ntls.patch | Public | Conditional Tongsuo NTLS |
| 05 | nginx-error_page_contains_apisix.patch | Public | Error page branding |
| 06 | nginx-get_last_reopen_time.patch | Public | Log reopen timestamp |
| 07 | nginx-grpc_set_header_authority.patch | Public | gRPC authority header |
| 08 | nginx-gzip.patch | Public | Dynamic compression settings |
| 09 | nginx-listen-in-privileged-agent.patch | Public | Agent listener selection |
| 10 | nginx-mirror.patch | Public | On-demand mirroring |
| 11 | nginx-privileged_agent_process_thread.patch | Public | Agent thread pool |
| 12 | nginx-proxy_request_buffering.patch | Adapt | Request buffering decision |
| 13 | nginx-real_ip.patch | Public | Real address API |
| 14 | nginx-stream_metrics.patch | Public | Stream session reasons |
| 15 | nginx-stream_upstream_mtls.patch | Adapt | Stream upstream certificates |
| 16 | nginx-tcp_over_tls.patch | Public | Dynamic stream upstream TLS |
| 17 | nginx-upstream_mtls.patch | Adapt | HTTP upstream certificates |
| 18 | nginx-upstream_pass_trailers.patch | Public | Upstream trailer policy |
| 19 | lua-resty-core-enable_keepalive.patch | Public | Lua keepalive pool options |
| 20 | lua-resty-core-init_worker_coroutine.patch | Public | Lua worker coroutine checks |
| 21 | lua-resty-core-reject-in-handshake.patch | Public | Lua certificate rejection option |
| 22 | lua-resty-core-shared_shdict.patch | Public | Lua dictionary API bindings |
| 23 | lua-resty-core-ssl_session_hostname.patch | Public | Lua TLS session hostname |
| 24 | lua-resty-core-tlshandshake.patch | Adapt | Lua TLS handshake wrapper |
| 25 | ngx_lua-enable_keepalive.patch | Public | Native HTTP keepalive pools |
| 26 | ngx_lua-init_worker_coroutine.patch | Public | Native HTTP worker coroutines |
| 27 | ngx_lua-reject-in-handshake.patch | Public | HTTP certificate rejection |
| 28 | ngx_lua-request_header_set.patch | Adapt | Header update notification |
| 29 | ngx_lua-shared_shdict.patch | Adapt | HTTP dictionary integration |
| 30 | ngx_lua-skip_filter.patch | Public | HTTP filter bypass control |
| 31 | ngx_lua-ssl_session_hostname.patch | Public | HTTP TLS session hostname |
| 32 | ngx_lua-tlshandshake.patch | Public | HTTP cosocket TLS handshake |
| 33 | ngx_stream_lua-expose_request_struct.patch | Public | Stream request structure API |
| 34 | ngx_stream_lua-reject-in-handshake.patch | Public | Stream certificate rejection |
| 35 | ngx_stream_lua-shared_shdict.patch | Adapt | Stream dictionary integration |
| 36 | ngx_stream_lua-ssl_session_hostname.patch | Public | Stream TLS session hostname |
| 37 | ngx_stream_lua-tlshandshake.patch | Adapt | Stream cosocket TLS handshake |
| 38 | ngx_stream_lua-xrpc.patch | Adapt | Stream bounded socket operations |

## 10 Evidence to retain before publishing the patching page

Record archive URLs and hashes, exact bundled versions, RPM inventory, all 38 patch logs, generated patch hashes, the fresh replay result, compiler/configure flags, nginx -V, ldd output, APISIX version/init/test output and final HTTP/log results. Publish the procedure after the work-environment dry run passes. Label each feature as source-integrated, compiled, or functionally tested so management does not read an HTTP route test as coverage of every feature.
