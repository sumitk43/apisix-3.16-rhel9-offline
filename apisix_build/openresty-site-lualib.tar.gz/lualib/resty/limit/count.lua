-- implement GitHub request rate limiting:
--    https://developer.github.com/v3/#rate-limiting

local ngx_shared = ngx.shared
local setmetatable = setmetatable
local assert = assert


local _M = {
   _VERSION = '1.0.0'
}


local mt = {
    __index = _M
}

local incr_support_init_ttl
local ngx_config = ngx.config
local ngx_lua_v = ngx.config.ngx_lua_version
if not ngx_config or not ngx_lua_v or (ngx_lua_v < 10012) then
    incr_support_init_ttl = false
else
    incr_support_init_ttl = true
end


-- the "limit" argument controls number of request allowed in a time window.
-- time "window" argument controls the time window in seconds.
function _M.new(dict_name, limit, window)
    local dict = ngx_shared[dict_name]
    if not dict then
        return nil, "shared dict not found"
    end

    assert(limit > 0 and window > 0)

    local self = {
        dict = dict,
        limit = limit,
        window = window,
    }

    return setmetatable(self, mt)
end

-- incoming function using incr with init_ttl
-- need OpenResty version > v0.10.12rc2
-- parameter "cost" is only supported on the new interface
local function incoming_new(self, key, commit, cost)
    cost = cost or 1

    local dict = self.dict
    local limit = self.limit
    local window = self.window

    local consumed, ok, err

    if commit then
        consumed, err = dict:incr(key, cost, 0, window)
        if not consumed then
            return nil, err
        end
    else
        consumed = (dict:get(key) or 0) + cost
    end

    if consumed > limit then
        return nil, "rejected"
    end

    return 0, consumed
end

-- incoming function using incr and expire
local function incoming_old(self, key, commit)
    local dict = self.dict
    local limit = self.limit
    local window = self.window
    local remaining, ok, err

    if commit then
        remaining, err = dict:incr(key, -1, limit)
        if not remaining then
            return nil, err
        end

        if remaining == limit - 1 then
            ok, err = dict:expire(key, window)
            if not ok then
                if err == "not found" then
                    remaining, err = dict:incr(key, -1, limit)
                    if not remaining then
                        return nil, err
                    end

                    ok, err = dict:expire(key, window)
                    if not ok then
                        return nil, err
                    end

                else
                    return nil, err
                end
            end
        end

    else
        remaining = (dict:get(key) or limit) - 1
    end

    if remaining < 0 then
        return nil, "rejected"
    end

    return 0, remaining
end

_M.incoming = incr_support_init_ttl and incoming_new or incoming_old

-- uncommit remaining and return remaining value
function _M.uncommit(self, key)
    assert(key)
    local dict = self.dict
    local limit = self.limit

    local consumed, err = dict:incr(key, -1)
    if not consumed then
        if err == "not found" then
            consumed = limit
        else
            return nil, err
        end
    end

    return consumed
end


return _M
